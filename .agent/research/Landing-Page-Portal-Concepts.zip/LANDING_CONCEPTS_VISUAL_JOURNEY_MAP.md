# 🎨 LANDING PAGE CONCEPTS - VISUAL JOURNEY MAP
## Scene-by-Scene Comparison

**Designer:** UI/UX Lead  
**Date:** February 12, 2026  
**Purpose:** Visual guide to help USER understand each concept's journey

---

## 📍 JOURNEY OVERVIEW

### **CONCEPT 1: THE CONSTELLATION**
```
VOID → HEXAGON → NETWORK → HELIX → GRID
(Chaos)  (Safety)  (Connect)  (Intel)  (Unity)
```

### **CONCEPT 2: THE PRISM**
```
BLUR → FACET 1 → FACET 2 → FACET 3 → CRYSTAL
(Fog)   (Safety)   (Network)  (Intel)   (Clarity)
```

### **CONCEPT 3: THE PORTAL SEQUENCE**
```
2D → BREACH → 3D CARDS → TOWERS → TIMELINE → ORBIT
(Flat) (Break)  (Safety)   (Network) (4D Time)  (Unity)
```

---

## 🎬 SCENE-BY-SCENE BREAKDOWN

### **SCENE 1: THE HERO (Above Fold)**

#### **CONCEPT 1: The Void**
```
┌─────────────────────────────────────────────────────┐
│                                                     │
│         · · ·  · ·   ·  ·  · ·   ·  ·  ·           │
│      ·   ·  ·    ·  ·  ·   ·  ·    ·   ·  ·        │
│   ·  ·   ·  ·  ·   ·  ·  ·   ·  ·  ·   ·  ·  ·     │
│                                                     │
│              ╭─────────────────╮                    │
│              │   ◉ PORTAL ◉   │                    │
│              │   (glowing)     │                    │
│              ╰─────────────────╯                    │
│                                                     │
│         STANDARDIZED OUTCOMES.                      │
│         BENCHMARKED SAFETY.                         │
│                                                     │
│   [ACCESS PORTAL]  [REQUEST ACCESS]                 │
│                                                     │
│   12k+ RECORDS | 840+ CLINICIANS | 98% UPTIME      │
│                                                     │
│         · · ·  · ·   ·  ·  · ·   ·  ·  ·           │
└─────────────────────────────────────────────────────┘
```
**Vibe:** Dark, mysterious, particles floating
**Interaction:** Particles follow mouse (magnetic)
**Emotion:** Lost in chaos, searching

---

#### **CONCEPT 2: The Blur**
```
┌─────────────────────────────────────────────────────┐
│  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░░░░░░░░░░░░  ╱◆◆◆◆◆╲  ░░░░░░░░░░░░░░░░░░░░░░  │
│  ░░░░░░░░░░░  ╱  PRISM  ╲  ░░░░░░░░░░░░░░░░░░░░  │
│  ░░░░░░░░░░░  ╲ (glass) ╱  ░░░░░░░░░░░░░░░░░░░░  │
│  ░░░░░░░░░░░░  ╲◆◆◆◆◆╱  ░░░░░░░░░░░░░░░░░░░░░░  │
│  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░░░░  S̶T̶A̶N̶D̶A̶R̶D̶I̶Z̶E̶D̶ ̶O̶U̶T̶C̶O̶M̶E̶S̶.̶  ░░░░  │
│  ░░░░  B̶E̶N̶C̶H̶M̶A̶R̶K̶E̶D̶ ̶S̶A̶F̶E̶T̶Y̶.̶  ░░░░░░░  │
│  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░░  [ACCESS PORTAL]  [REQUEST ACCESS]  ░░░░░░░░  │
│  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
└─────────────────────────────────────────────────────┘
```
**Vibe:** Blurred, frosted glass, chromatic aberration
**Interaction:** Mouse tilts prism (3D perspective)
**Emotion:** Confused, uncertain, seeking clarity

---

#### **CONCEPT 3: The Flat World**
```
┌─────────────────────────────────────────────────────┐
│ ████████████████████████████████████████████████████│
│ ██                                                ██│
│ ██  > INITIALIZING PPN RESEARCH PORTAL...        ██│
│ ██  > LOADING CLINICAL INTELLIGENCE SYSTEM...    ██│
│ ██  > STANDARDIZED OUTCOMES. BENCHMARKED SAFETY. ██│
│ ██  > _                                           ██│
│ ██                                                ██│
│ ██              ╭─────────────╮                   ██│
│ ██              │  ◉ PORTAL  │  (3D, glowing)    ██│
│ ██              │  (pulsing)  │                   ██│
│ ██              ╰─────────────╯                   ██│
│ ██                                                ██│
│ ██  > SYSTEM STATUS:                              ██│
│ ██  > RECORDS: 12,482                             ██│
│ ██  > CLINICIANS: 840+                            ██│
│ ██  > UPTIME: 98%                                 ██│
│ ██                                                ██│
│ ██         [ENTER THE PORTAL]                     ██│
│ ██                                                ██│
│ ████████████████████████████████████████████████████│
└─────────────────────────────────────────────────────┘
```
**Vibe:** Retro terminal, 2D, monospace font
**Interaction:** Cursor pulled toward portal (magnetic)
**Emotion:** Constrained, trapped in old system

---

## 🎬 SCENE 2: FIRST TREASURE

### **CONCEPT 1: Safety Constellation (Hexagon)**
```
┌─────────────────────────────────────────────────────┐
│                                                     │
│              ◉ MedDRA                               │
│           ╱     │     ╲                             │
│        ◉ 0 Events ─── ◉ CTCAE                       │
│           │       │       │                         │
│        ◉ Alerts ─ ◉ ─ ◉ Multi-Site                  │
│           ╲     │     ╱                             │
│           ◉ Notifications                           │
│                                                     │
│        [Hexagonal lattice with glowing nodes]       │
│        [Light beams connecting nodes]               │
│        [Nodes bob gently like zero-gravity]         │
│                                                     │
│   · · ·  (remaining particles in background) · ·   │
└─────────────────────────────────────────────────────┘
```
**Treasure:** Safety Surveillance  
**Interaction:** Hover node → Detail card projects outward  
**Emotion:** Discovery, structure emerging from chaos

---

### **CONCEPT 2: Safety Facet (Prism Side 1)**
```
┌─────────────────────────────────────────────────────┐
│  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░░░░░░░░  ╱◆◆◆◆◆╲  ░░░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░░░░░░░  ╱ ┌─────┐ ╲  ░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░░░░░░  ╱  │SAFETY│  ╲  ░░░░░░░░░░░░░░░░░░░░░  │
│  ░░░░░  ╱   │ 0 EVT│   ╲  ░░░░░░░░░░░░░░░░░░░░  │
│  ░░░░  ╱    │ALERTS│    ╲  ░░░░░░░░░░░░░░░░░░░  │
│  ░░░  ╱     │CODED │     ╲  ░░░░░░░░░░░░░░░░░░  │
│  ░░  ╱      └─────┘      ╲  ░░░░░░░░░░░░░░░░░  │
│  ░  ╲◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆╱  ░░░░░░░░░░░░░░░░  │
│  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░░  [Prism facet shows holographic dashboard]  ░  │
│  ░░  [Background blur: 28px (30% clearer)]  ░░░░░  │
└─────────────────────────────────────────────────────┘
```
**Treasure:** Safety Surveillance  
**Interaction:** Hover data → Projects from prism with light ray  
**Emotion:** Clarity emerging, fog lifting

---

### **CONCEPT 3: 3D Safety Cards**
```
┌─────────────────────────────────────────────────────┐
│ ═══════════════════════════════════════════════════ │
│ ═══════════════════════════════════════════════════ │
│ ═══                                             ═══ │
│ ═══    ┌────────┐        ┌────────┐            ═══ │
│ ═══    │ 0 EVTS │        │ ALERTS │            ═══ │
│ ═══    │ (green)│        │ (blue) │            ═══ │
│ ═══    └────────┘        └────────┘            ═══ │
│ ═══                                             ═══ │
│ ═══         ┌────────┐                         ═══ │
│ ═══         │ CODED  │  (draggable cards)      ═══ │
│ ═══         │ (white)│  (floating in 3D)       ═══ │
│ ═══         └────────┘                         ═══ │
│ ═══                                             ═══ │
│ ═══  ┌────────┐              ┌────────┐        ═══ │
│ ═══  │ NOTIFY │              │ MULTI  │        ═══ │
│ ═══  │ (red)  │              │ (blue) │        ═══ │
│ ═══  └────────┘              └────────┘        ═══ │
│ ═══                                             ═══ │
│ ═══  [Grid lines extend infinitely]             ═══ │
│ ═══════════════════════════════════════════════════ │
└─────────────────────────────────────────────────────┘
```
**Treasure:** Safety Surveillance  
**Interaction:** Drag cards, they collide with physics  
**Emotion:** Freedom, exploring 3D space

---

## 🎬 SCENE 3: SECOND TREASURE

### **CONCEPT 1: Network Constellation (Circle)**
```
┌─────────────────────────────────────────────────────┐
│                                                     │
│              ◉ Baltimore                            │
│         ◉ London    ◉ Zurich                        │
│     ◉ Amsterdam ╭─────╮ ◉ Palo Alto                │
│                 │ 840+│                             │
│     ◉ Toronto   │CLINS│   ◉ Sydney                 │
│                 ╰─────╯                             │
│     ◉ Tokyo        ◉ São Paulo                     │
│         ◉ Mexico    ◉ Cape Town                     │
│              ◉ Mumbai                               │
│                                                     │
│   [14 glowing towers in circular pattern]           │
│   [Light beams connecting all towers]               │
│   [Data pulses travel along beams]                  │
│                                                     │
└─────────────────────────────────────────────────────┘
```
**Treasure:** Network Benchmarking  
**Interaction:** Click tower → Zoom in, see site details  
**Emotion:** Connected, part of global network

---

### **CONCEPT 2: Network Facet (Prism Side 2)**
```
┌─────────────────────────────────────────────────────┐
│  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░░░░  ╱◆◆◆◆◆╲  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░░  ╱  ◉───◉  ╲  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░  ╱  ◉ ╲ ╱ ◉  ╲  ░░░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░ ╱   ◉─◉─◉─◉   ╲  ░░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░╱    ◉ ╱ ╲ ◉    ╲  ░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ╱     ◉───◉      ╲  ░░░░░░░░░░░░░░░░░░░░░░░  │
│  ╲◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆╱  ░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░  [14 nodes on prism surface]  ░░░░░░░░░░░░░░░  │
│  ░  [Light beams connecting nodes]  ░░░░░░░░░░░░  │
│  ░  [Background blur: 16px (60% clearer)]  ░░░░░  │
└─────────────────────────────────────────────────────┘
```
**Treasure:** Network Benchmarking  
**Interaction:** Click node → Prism zooms in on facet  
**Emotion:** Clarity increasing, network visible

---

### **CONCEPT 3: Network Towers**
```
┌─────────────────────────────────────────────────────┐
│ ═══════════════════════════════════════════════════ │
│ ═══                                             ═══ │
│ ═══    ║  ║    ║  ║    ║  ║    ║  ║           ═══ │
│ ═══    ║  ║    ║  ║    ║  ║    ║  ║           ═══ │
│ ═══    ║  ║    ║  ║    ║  ║    ║  ║           ═══ │
│ ═══    ║  ║    ║  ║    ║  ║    ║  ║           ═══ │
│ ═══    ║  ║────║  ║────║  ║────║  ║           ═══ │
│ ═══    ║  ║    ║  ║    ║  ║    ║  ║           ═══ │
│ ═══    ║  ║    ║  ║    ║  ║    ║  ║           ═══ │
│ ═══    ║  ║    ║  ║    ║  ║    ║  ║           ═══ │
│ ═══════╬══╬════╬══╬════╬══╬════╬══╬═══════════════ │
│ ═══════╬══╬════╬══╬════╬══╬════╬══╬═══════════════ │
│ ═══    BAL  LON  ZUR  PAL  AMS  TOR  SYD  TOK  ═══ │
│ ═══                                             ═══ │
│ ═══  [14 data towers rising from grid]          ═══ │
│ ═══  [Light beams connecting towers]            ═══ │
│ ═══  [Grid warps around towers (gravity)]       ═══ │
└─────────────────────────────────────────────────────┘
```
**Treasure:** Network Benchmarking  
**Interaction:** Click tower → Camera zooms, time slows  
**Emotion:** Awe, scale of network

---

## 🎬 FINAL SCENE: CONVERGENCE

### **CONCEPT 1: Bento Grid**
```
┌─────────────────────────────────────────────────────┐
│                                                     │
│   ┌──────────────┐  ┌──────┐  ┌──────────────┐    │
│   │   PROTOCOL   │  │SAFETY│  │  ANALYTICS   │    │
│   │   BUILDER    │  │SURVL │  │  DASHBOARD   │    │
│   │   (large)    │  │(med) │  │   (large)    │    │
│   └──────────────┘  └──────┘  └──────────────┘    │
│                                                     │
│   ┌──────┐  ┌──────────────┐  ┌──────┐            │
│   │INTXN │  │   OUTCOME    │  │NETWK │            │
│   │CHECK │  │   TRACKING   │  │INSIT │            │
│   │(sml) │  │   (medium)   │  │(sml) │            │
│   └──────┘  └──────────────┘  └──────┘            │
│                                                     │
│         [ENTER THE PORTAL]                          │
│         (holographic shimmer button)                │
│                                                     │
│   [Background: Deep indigo (dawn breaking)]         │
│   [All particles now form perfect grid]             │
└─────────────────────────────────────────────────────┘
```
**Emotion:** Unity achieved, order from chaos

---

### **CONCEPT 2: Perfect Crystal**
```
┌─────────────────────────────────────────────────────┐
│                                                     │
│                    ╱╲                               │
│                   ╱  ╲                              │
│                  ╱ ◆  ╲                             │
│                 ╱  ◆◆  ╲                            │
│                ╱   ◆◆   ╲                           │
│               ╱    ◆◆    ╲                          │
│              ╱     ◆◆     ╲                         │
│             ╱      ◆◆      ╲                        │
│            ╱       ◆◆       ╲                       │
│           ╱        ◆◆        ╲                      │
│          ╱         ◆◆         ╲                     │
│         ╱          ◆◆          ╲                    │
│        ╱___________◆◆___________╲                   │
│                                                     │
│   [Perfect geometric crystal (octahedron)]          │
│   [Each facet shows a feature]                      │
│   [Rainbow light converges to white]                │
│   [Background: Pure white (perfect clarity)]        │
│                                                     │
│         [ENTER THE PORTAL]                          │
│         (glowing crystal button)                    │
└─────────────────────────────────────────────────────┘
```
**Emotion:** Enlightenment, perfect clarity achieved

---

### **CONCEPT 3: Orbital Satellites**
```
┌─────────────────────────────────────────────────────┐
│ ═══════════════════════════════════════════════════ │
│ ═══                                             ═══ │
│ ═══        ◉ Protocol                           ═══ │
│ ═══    ◉ Safety    ◉ Analytics                  ═══ │
│ ═══                                             ═══ │
│ ═══  ◉ Intxn   ╭─────────╮   ◉ Outcome          ═══ │
│ ═══            │ ◉◉◉◉◉  │                      ═══ │
│ ═══            │ PORTAL  │                      ═══ │
│ ═══            │ ◉◉◉◉◉  │                      ═══ │
│ ═══  ◉ Network ╰─────────╯   ◉ Privacy          ═══ │
│ ═══                                             ═══ │
│ ═══    ◉ Tracking  ◉ Intel                      ═══ │
│ ═══        ◉ Controls                           ═══ │
│ ═══                                             ═══ │
│ ═══  [8 glass spheres orbiting central portal]  ═══ │
│ ═══  [Each sphere contains feature icon]        ═══ │
│ ═══  [Spheres have realistic physics/gravity]   ═══ │
│ ═══                                             ═══ │
│ ═══         [ACCESS THE PORTAL]                 ═══ │
│ ═══════════════════════════════════════════════════ │
└─────────────────────────────────────────────────────┘
```
**Emotion:** Transcendence, all dimensions unified

---

## 🎯 KEY DIFFERENCES SUMMARY

| **Aspect** | **Constellation** | **Prism** | **Portal Sequence** |
|------------|-------------------|-----------|---------------------|
| **Hero Feel** | Dark void, mysterious | Blurred, foggy | Retro terminal, flat |
| **Transition** | Particle migration | Prism rotation | Portal breach |
| **Treasure 1** | Hexagon lattice | Holographic facet | Draggable 3D cards |
| **Treasure 2** | Circular network | Node visualization | Data towers |
| **Treasure 3** | DNA helix | Bento grid | 4D timeline |
| **Finale** | Perfect grid | Perfect crystal | Orbital satellites |
| **Emotion Arc** | Chaos → Unity | Confusion → Clarity | Constrained → Free |
| **Metaphor** | Particles → Structure | Blur → Sharp | 2D → 3D → 4D |

---

## 🎨 WHICH JOURNEY RESONATES?

**CONCEPT 1:** The journey from **scattered particles** to **unified constellation**  
**CONCEPT 2:** The journey from **blurred fog** to **crystal clarity**  
**CONCEPT 3:** The journey from **flat 2D** to **infinite 3D/4D**  

---

**DESIGNER:** This visual guide should help you imagine each concept's journey. Which transformation speaks to you? 🚀
